package com.example.student_management_system;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.example.student_management_system.Student;
import com.example.student_management_system.StudentService;
@Controller
public class StudentController {
@Autowired
private StudentService studentService;
// Display list of students
@GetMapping("/")
public String viewHomePage(Model model) {
model.addAttribute("listStudents", studentService.getAllStudents())
;
return "index";
}
@GetMapping("/showNewStudentForm")
public String showNewStudentForm(Model model) {
// Create model attribute to bind form data

Student student = new Student();
model.addAttribute("student", student);
return "new_student";
}
@PostMapping("/saveStudent")
public String saveStudent(@ModelAttribute("student") Student student) {
// Save student to database
studentService.saveStudent(student);
return "redirect:/";
}
@GetMapping("/showFormForUpdate/{id}")
public String showFormForUpdate(@PathVariable(value = "id") long id, Model model) {
// Get student from the service
Student student = studentService.getStudentById(id);
// Set student as a model attribute to pre-populate the form
model.addAttribute("student", student);
return "update_student";
}
@GetMapping("/deleteStudent/{id}")
public String deleteStudent(@PathVariable(value = "id") long id) {
// Call delete student method
this.studentService.deleteStudentById(id);
return "redirect:/";
}
}
